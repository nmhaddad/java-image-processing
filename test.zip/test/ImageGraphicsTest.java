import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.function.Consumer;

import image.control.ImageController;
import image.control.ImageControllerImplInteractive;
import image.model.ImageModel;
import image.model.ImageModelImpl;
import image.view.ImageGraphics;
import image.view.ImageView;

import static image.model.ImageUtil.readImage;

/**
 * A JUnit test class for the image view interface and its image graphics implementation.
 */
public class ImageGraphicsTest {

  private ImageView testView;

  private ImageController testController;

  private ImageModel testModel;

  @Before
  public void setUp() {
    testView = new ImageGraphics();
    testModel = new ImageModelImpl();
    testController = new ImageControllerImplInteractive(testView, testModel);
  }

  @Test
  public void TestMakeVisible() {

  }

  @Test
  public void testSetCommandCallback() {

  }

  @Test
  public void testGetCommand() {

  }

  @Test
  public void testShowErrorMessage() {

  }

  @Test
  public void TestSetImage() throws IOException {

  }

  @Test
  public void testRefresh() {

  }

}
